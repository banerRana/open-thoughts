from .__python_wrapper__ import BLEU, SelfBLEU

__all__ = ['BLEU', 'SelfBLEU']
